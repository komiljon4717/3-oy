                    // create user
let createFullName = document.querySelector("#createFullName")
let createUsername = document.querySelector("#createUsername")
let createEmail = document.querySelector("#createEmail")
let createBio = document.querySelector("#createBio")
let createPassword = document.querySelector("#createPassword")
let confrimPassword = document.querySelector("#confrimPassword")
                    // user






let saveBtn = document.querySelector("#save-btn")
let userList = document.querySelector('#userlist')
let tbody = document.querySelector('tbody')
let tableBordered = document.querySelector('.table table-bordered')

// databases
let users = window.localStorage.getItem('users')
users = JSON.parse(users) || []



function createElements(...arr){
    return arr.map( el => {
        return document.createElement(el)
    })
}



function createUser(params) {
    if (!(createFullName.value.trim().length < 30 && createFullName.value.trim())) {
        return alert('Wrong Fullname')
    }
    if (!(createUsername.value.trim().length < 30 && createUsername.value.trim())) {
        return alert('Wrong username')
    }
    if (!(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/).test(createEmail.value)) {
        return alert('Wrong Email')
    }
    if (!((/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/).test(createPassword.value) == (/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/).test(confrimPassword.value))) {
        return alert('Wrong password')
    }

    users.push({
        userId: users.length ? +users.at(-1).userId + 1 : 1,
        fullName : createFullName.value,
        username : createUsername.value,
        email: createEmail.value,
        password: createPassword.value,
        date: new Date().toLocaleDateString("en-US"),
        bio: createBio.value

    })
    window.localStorage.setItem('users', JSON.stringify(users))
    createFullName.value = null
    createUsername.value = null
    createEmail.value = null
    createPassword.value = null
    createBio.value = null
}

function renderUsers(users) {
    for (const user of users) {
        const [td1, div1, input, label, td2, td3, td4, td5, div2, ] = createElements('td', 'div', 'input', 'label', 'td', 'td', 'td', 'td', 'div')
        td1.classList.add('align-middle')
        div1.classList.add('custom-control', 'custom-control-inline', 'custom-checkbox', 'custom-control-nameless', 'm-0', 'align-top')
        input.classList.add('custom-control-input')
        input.setAttribute('type', "checkbox")
        input.id = "item-1"
        label.classList.add('custom-control-label')
        label.setAttribute("for", "item-1")
        div1.append(input, label)
        td1.append(div1)
        td2.classList.add('text-nowrap', 'align-middle')
        td2.textContent = user.fullName
        td3.classList.add('text-nowrap', 'align-middle')
        td3.innerHTML = `<span>${user.date}</span>`
        td4.classList.add('text-center', 'align-middle')
        td4.innerHTML = `<i class="fa fa-fw text-secondary cursor-pointer fa-toggle-on"></i>`
        td5.classList.add('text-center', 'align-middle')
        console.log(td5);
        div2.classList.add('btn-group', 'align-top')
        div2.innerHTML = `<button class="btn btn-sm btn-outline-secondary badge" type="button" data-toggle="modal" data-target="#user-edit">Edit</button>
        <button class="btn btn-sm btn-outline-secondary badge" type="button"><i class="fa fa-trash"></i></button>`
        td5.append(div2)

        userList.append(td1, td2, td3, td4, td5)
        tbody.append(userList)
    }
}


renderUsers(users)










// console.log(new Date('Jul 12 2011').toString());

saveBtn.onclick = (event) => {
    event.preventDefault()
    console.log("bosildi");
    createUser()
    // createtable.innerHTML = null
}


























function globalFilter(data) {
    
}